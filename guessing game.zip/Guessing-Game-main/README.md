# Guessing-Game

The system will select a random number/integer and the user will have to guess that number. 
The user will have 3 chances to guess the correct number or he/she will lose the game.
